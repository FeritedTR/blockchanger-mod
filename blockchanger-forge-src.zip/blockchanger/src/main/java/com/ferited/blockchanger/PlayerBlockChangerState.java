package com.ferited.blockchanger;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Her oyuncunun BlockChanger durumunu (açık/kapalı ve seçili blok) tutar.
 */
public class PlayerBlockChangerState {

    private static final Map<UUID, Boolean> enabledMap = new HashMap<>();
    private static final Map<UUID, Block> blockMap = new HashMap<>();

    public static boolean isEnabled(UUID playerId) {
        return enabledMap.getOrDefault(playerId, false);
    }

    public static void setEnabled(UUID playerId, boolean enabled) {
        enabledMap.put(playerId, enabled);
    }

    public static void toggle(UUID playerId) {
        enabledMap.put(playerId, !isEnabled(playerId));
    }

    public static Block getSelectedBlock(UUID playerId) {
        return blockMap.getOrDefault(playerId, Blocks.DIAMOND_BLOCK);
    }

    public static boolean setSelectedBlock(UUID playerId, String blockId) {
        ResourceLocation rl = ResourceLocation.tryParse(blockId);
        if (rl == null) return false;

        Block block = ForgeRegistries.BLOCKS.getValue(rl);
        if (block == null || block == Blocks.AIR) return false;

        blockMap.put(playerId, block);
        return true;
    }

    public static String getSelectedBlockId(UUID playerId) {
        Block block = getSelectedBlock(playerId);
        ResourceLocation rl = ForgeRegistries.BLOCKS.getKey(block);
        return rl != null ? rl.toString() : "minecraft:diamond_block";
    }
}
