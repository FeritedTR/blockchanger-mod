package com.ferited.blockchanger.event;

import com.ferited.blockchanger.BlockChangerMod;
import com.ferited.blockchanger.PlayerBlockChangerState;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class BlockHitHandler {

    /**
     * LeftClickBlock: oyuncu bir bloğa sol tıkladığında (vurma) tetiklenir.
     * Bu sunucu tarafında çalışır, dolayısıyla setBlock güvenlidir.
     */
    @SubscribeEvent
    public void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
        // Sadece sunucu tarafı
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!(event.getLevel() instanceof ServerLevel serverLevel)) return;

        // Oyuncu aktif mi?
        if (!PlayerBlockChangerState.isEnabled(player.getUUID())) return;

        BlockPos pos = event.getPos();
        BlockState currentState = serverLevel.getBlockState(pos);

        // Hava veya sıvı bloklarını atlat
        if (currentState.isAir() || currentState.liquid()) return;

        // Bedrock'u koruyalım (op abuse önlemi)
        if (currentState.getBlock() == net.minecraft.world.level.block.Blocks.BEDROCK) {
            if (!player.hasPermissions(4)) return;
        }

        Block targetBlock = PlayerBlockChangerState.getSelectedBlock(player.getUUID());
        BlockState newState = targetBlock.defaultBlockState();

        // Bloğu değiştir
        serverLevel.setBlock(pos, newState, Block.UPDATE_ALL);

        BlockChangerMod.LOGGER.debug("[BlockChanger] {} -> {} at {}",
                currentState.getBlock().getDescriptionId(),
                targetBlock.getDescriptionId(),
                pos);
    }
}
