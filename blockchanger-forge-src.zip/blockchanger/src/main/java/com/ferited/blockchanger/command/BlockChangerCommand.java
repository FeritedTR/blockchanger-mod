package com.ferited.blockchanger.command;

import com.ferited.blockchanger.PlayerBlockChangerState;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.concurrent.CompletableFuture;

public class BlockChangerCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
            Commands.literal("blockchanger")
                // /blockchanger on
                .then(Commands.literal("on")
                    .executes(ctx -> setEnabled(ctx, true)))
                // /blockchanger off
                .then(Commands.literal("off")
                    .executes(ctx -> setEnabled(ctx, false)))
                // /blockchanger toggle
                .then(Commands.literal("toggle")
                    .executes(BlockChangerCommand::toggle))
                // /blockchanger set <block_id>
                .then(Commands.literal("set")
                    .then(Commands.argument("block", StringArgumentType.string())
                        .suggests(BlockChangerCommand::suggestBlocks)
                        .executes(ctx -> setBlock(ctx, StringArgumentType.getString(ctx, "block")))))
                // /blockchanger status
                .then(Commands.literal("status")
                    .executes(BlockChangerCommand::status))
        );
    }

    private static int setEnabled(CommandContext<CommandSourceStack> ctx, boolean enabled) {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal("Bu komut sadece oyuncular tarafından kullanılabilir."));
            return 0;
        }

        PlayerBlockChangerState.setEnabled(player.getUUID(), enabled);
        String blockId = PlayerBlockChangerState.getSelectedBlockId(player.getUUID());

        if (enabled) {
            player.sendSystemMessage(Component.literal(
                "§a[BlockChanger] §fAçıldı! Seçili blok: §e" + blockId
            ));
        } else {
            player.sendSystemMessage(Component.literal(
                "§c[BlockChanger] §fKapatıldı."
            ));
        }
        return 1;
    }

    private static int toggle(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal("Bu komut sadece oyuncular tarafından kullanılabilir."));
            return 0;
        }

        PlayerBlockChangerState.toggle(player.getUUID());
        boolean nowEnabled = PlayerBlockChangerState.isEnabled(player.getUUID());
        String blockId = PlayerBlockChangerState.getSelectedBlockId(player.getUUID());

        if (nowEnabled) {
            player.sendSystemMessage(Component.literal(
                "§a[BlockChanger] §fAçıldı! Seçili blok: §e" + blockId
            ));
        } else {
            player.sendSystemMessage(Component.literal(
                "§c[BlockChanger] §fKapatıldı."
            ));
        }
        return 1;
    }

    private static int setBlock(CommandContext<CommandSourceStack> ctx, String blockId) {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal("Bu komut sadece oyuncular tarafından kullanılabilir."));
            return 0;
        }

        // Namespace yoksa minecraft: ekle
        String fullId = blockId.contains(":") ? blockId : "minecraft:" + blockId;

        boolean success = PlayerBlockChangerState.setSelectedBlock(player.getUUID(), fullId);
        if (success) {
            player.sendSystemMessage(Component.literal(
                "§b[BlockChanger] §fSeçili blok §e" + fullId + " §folarak ayarlandı."
            ));
            return 1;
        } else {
            player.sendSystemMessage(Component.literal(
                "§c[BlockChanger] §fGeçersiz blok ID: §e" + fullId
            ));
            return 0;
        }
    }

    private static int status(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal("Bu komut sadece oyuncular tarafından kullanılabilir."));
            return 0;
        }

        boolean enabled = PlayerBlockChangerState.isEnabled(player.getUUID());
        String blockId = PlayerBlockChangerState.getSelectedBlockId(player.getUUID());

        player.sendSystemMessage(Component.literal(
            "§6[BlockChanger] §fDurum: " +
            (enabled ? "§aAçık" : "§cKapalı") +
            " §f| Seçili blok: §e" + blockId
        ));
        return 1;
    }

    private static CompletableFuture<Suggestions> suggestBlocks(
            CommandContext<CommandSourceStack> ctx,
            SuggestionsBuilder builder) {

        String input = builder.getRemaining().toLowerCase();

        ForgeRegistries.BLOCKS.getKeys().stream()
            .map(rl -> rl.toString())
            .filter(id -> id.contains(input))
            .limit(50)
            .forEach(builder::suggest);

        return builder.buildFuture();
    }
}
