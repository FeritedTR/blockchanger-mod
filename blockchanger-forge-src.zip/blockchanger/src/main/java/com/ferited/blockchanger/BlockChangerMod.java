package com.ferited.blockchanger;

import com.ferited.blockchanger.command.BlockChangerCommand;
import com.ferited.blockchanger.event.BlockHitHandler;
import com.mojang.logging.LogUtils;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(BlockChangerMod.MOD_ID)
public class BlockChangerMod {

    public static final String MOD_ID = "blockchanger";
    public static final Logger LOGGER = LogUtils.getLogger();

    public BlockChangerMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        // Forge event bus (game events)
        MinecraftForge.EVENT_BUS.register(new BlockHitHandler());
        MinecraftForge.EVENT_BUS.addListener(this::onRegisterCommands);

        LOGGER.info("[BlockChanger] Mod yüklendi.");
    }

    private void onRegisterCommands(RegisterCommandsEvent event) {
        BlockChangerCommand.register(event.getDispatcher());
        LOGGER.info("[BlockChanger] Komutlar kaydedildi.");
    }
}
